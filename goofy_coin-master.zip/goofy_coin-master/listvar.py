goofy_list = None
