# goofy_coin
